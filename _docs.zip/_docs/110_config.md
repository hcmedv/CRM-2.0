# 110_config.md

# Konfiguration und Pfaddefinition

## Ziel

Zentrale Definition aller Systempfade.

Kein Modul darf eigene Root-Pfade definieren oder ableiten.

Alle Dateisystemzugriffe müssen über settings_crm erfolgen.

---

# Verbindliche Paths

paths.root  
paths.crm_config  
paths.crm_data  
paths.crm_archiv  
paths.kunden  
paths.log  
paths.tmp  

---

# Bedeutungen

## crm_config

Konfiguration  
settings_*.php  
secrets_*.php  

Keine Laufzeitdaten.

---

## crm_data

Systemzustand des CRM.

Enthält:

- stores
- cache
- raw
- queue
- state

Keine Kundendokumente.

---

## crm_archiv

System-Archiv.

Beispiel:

- rotierte raw Daten
- Snapshots
- Debug Archive

Keine Kundendokumente.

---

## kunden

Physischer Speicher für Kundendaten.

Struktur:

_kunden/<KN>/<modul>/<jahr>/<typ>/

---

# Verboten

- Direkte Nutzung von /data
- Hardcodierte Pfade
- __DIR__ . '/../data'
- Direkte String-Konkatenation zu Root-Pfaden

---

# Regel

Jeder Dateipfad wird ausschließlich über:

CRM_CFG('paths.xxx')

aufgelöst.
