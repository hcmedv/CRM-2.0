# 500_flow.md
# CRM V2 – SYSTEM FLOW

Status: Verbindliche Ablaufdefinition  
Zweck: Gesamtüberblick über Datenfluss und Verantwortlichkeiten

------------------------------------------------------------
------------------------------------------------------------

# 1. GESAMTABLAUF

Externer Trigger
        ↓
rules_<modul>_BuildPatch()
        ↓
(optional) rules_enrich.php
        ↓
CRM_EventGenerator::upsert()
        ↓
events.json
        ↓
crm_events_read.php
        ↓
api_*
        ↓
UI / Benutzer

------------------------------------------------------------
------------------------------------------------------------

# 2. TRIGGER-PHASE

Beispiele:

- PBX Webhook
- TeamViewer Poll
- M365 Sync
- User Action

Trigger liefert Rohdaten.

Trigger darf:

- timing bestimmen
- refs bestimmen
- meta.<source> befüllen

Trigger darf NICHT:

- workflow.state setzen
- Event schließen
- Event archivieren

------------------------------------------------------------
------------------------------------------------------------

# 3. PATCH-PHASE

rules_<modul>.php erzeugt ein Patch-Array.

Patch enthält typischerweise:

- event_source
- event_type
- timing
- refs
- meta.<source>
- optional display

Patch enthält NICHT:

- workflow
- created_at
- updated_at

------------------------------------------------------------
------------------------------------------------------------

# 4. ENRICH-PHASE (OPTIONAL)

rules_enrich.php kann:

- customer-Daten anhand KN anreichern
- display ergänzen
- meta erweitern

Enrich darf NICHT:

- workflow verändern
- state aus timing ableiten

------------------------------------------------------------
------------------------------------------------------------

# 5. WRITER-PHASE

CRM_EventGenerator::upsert()

Ablauf:

1. Event anhand refs[] suchen
2. Falls vorhanden → Merge
3. Falls nicht vorhanden → neues Event erzeugen
4. workflow.state default auf "open" setzen (nur bei Neu)
5. created_at setzen (nur bei Neu)
6. updated_at aktualisieren
7. events.json atomar speichern

------------------------------------------------------------
------------------------------------------------------------

# 6. MERGE-REGELN

Merge basiert ausschließlich auf:

refs[].ns + refs[].id

Regeln:

- workflow.state bleibt unverändert
- state wird nicht aus Triggerdaten übernommen
- timing wird ergänzt
- meta wird source-spezifisch erweitert
- display kann ergänzt werden

------------------------------------------------------------
------------------------------------------------------------

# 7. EVENTS STORE

events.json liegt unter:

<crm_data>/events.json

Zugriff ausschließlich über:

- crm_events_read.php
- crm_events_write.php

Keine andere Datei darf direkt zugreifen.

------------------------------------------------------------
------------------------------------------------------------

# 8. READER-PHASE

crm_events_read.php:

- lädt events.json
- filtert
- sucht
- sortiert
- liefert einzelne Events

Reader ist strikt read-only.

------------------------------------------------------------
------------------------------------------------------------

# 9. API-PHASE

api_* Dateien:

- verwenden Reader
- verwenden Writer

api_* dürfen NICHT:

- events.json direkt lesen
- events.json direkt schreiben
- Dateipfade kennen

------------------------------------------------------------
------------------------------------------------------------

# 10. UI-PHASE

Benutzer kann:

- workflow.state ändern
- worklog ergänzen
- Priorität setzen
- Notizen hinzufügen

Nur Benutzer verändert den fachlichen Zustand.

------------------------------------------------------------
------------------------------------------------------------

# 11. WORKLOAD-PRINZIP

Workload entsteht aus:

- timing
- optional worklog
- CRM-Rundungslogik

Beendete Session ≠ geschlossenes Event

Trigger-Zustände beeinflussen niemals workflow.state.

------------------------------------------------------------
------------------------------------------------------------

# 12. ARCHITEKTUR-SICHERHEIT

Durch diese Flow-Trennung ist garantiert:

- Trigger sind entkoppelt vom Workflow
- Events sind fachliche Container
- Der Event-Store ist geschützt
- Race Conditions werden vermieden
- Kundendaten sind physisch getrennt

------------------------------------------------------------
------------------------------------------------------------
