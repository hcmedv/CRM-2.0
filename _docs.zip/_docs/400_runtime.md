# 400_runtime.md
# CRM V2 – RUNTIME & EVENT STORE

Status: Verbindliche Laufzeitdefinition  
Zweck: Klare Regeln für Event-Zugriff, Merge und Persistenz

------------------------------------------------------------
------------------------------------------------------------

# 1. ZENTRALES PRINZIP

events.json ist der zentrale Event-Store.

Es gibt genau zwei Dateien, die darauf zugreifen dürfen:

- _lib/events/crm_events_read.php
- _lib/events/crm_events_write.php

Niemand sonst.

------------------------------------------------------------
------------------------------------------------------------

# 2. EVENTS STORE

Speicherort:

<crm_data>/events.json

Diese Datei enthält alle Events.

Regeln:

- Keine Moduldatei darf direkt zugreifen
- Keine API darf direkt zugreifen
- Kein raw_store darf darauf zugreifen

------------------------------------------------------------
------------------------------------------------------------

# 3. READER (crm_events_read.php)

Verantwortung:

- events.json laden
- JSON dekodieren
- filtern
- suchen
- sortieren
- einzelne Events liefern

Reader darf NICHT:

- schreiben
- patchen
- state ändern
- Merge durchführen

Reader ist rein lesend.

------------------------------------------------------------
------------------------------------------------------------

# 4. WRITER (crm_events_write.php)

Verantwortung:

- neues Event erzeugen
- Patch anwenden
- Merge durchführen
- workflow.state default setzen (open)
- created_at setzen
- updated_at aktualisieren
- idempotent prüfen (über refs[])
- events.json speichern

Writer ist die einzige schreibende Instanz.

------------------------------------------------------------
------------------------------------------------------------

# 5. PATCH-VERARBEITUNG

Ablauf:

1) Modul erzeugt Patch
2) Optional: Enrich ergänzt Daten
3) Writer erhält Patch
4) Writer sucht Event via refs[]
5) Wenn vorhanden → Merge
6) Wenn nicht vorhanden → neues Event

Patch darf KEINE:

- workflow.state
- created_at
- updated_at

setzen.

------------------------------------------------------------
------------------------------------------------------------

# 6. MERGE-PRINZIP

Merge basiert ausschließlich auf:

refs[].ns + refs[].id

Regeln:

- workflow.state bleibt unverändert
- workflow wird nicht aus Triggerdaten überschrieben
- timing wird ergänzt, nicht fachlich interpretiert
- meta wird source-spezifisch erweitert

------------------------------------------------------------
------------------------------------------------------------

# 7. WORKFLOW-REGEL

workflow.state wird:

- beim Erstellen auf "open" gesetzt (Default)
- ausschließlich durch Benutzer geändert

Trigger beeinflussen workflow niemals.

------------------------------------------------------------
------------------------------------------------------------

# 8. TIMING-REGEL

timing:

- wird vom Trigger geliefert
- kann ergänzt werden
- beeinflusst nicht workflow.state

duration_sec ist rein technisch.

------------------------------------------------------------
------------------------------------------------------------

# 9. API-LAYER

api_* Dateien dürfen:

- Reader verwenden
- Writer verwenden

api_* Dateien dürfen NICHT:

- events.json lesen
- events.json schreiben
- Dateisystempfade kennen

------------------------------------------------------------
------------------------------------------------------------

# 10. TRANSAKTIONSPRINZIP

Writer muss:

- atomar speichern
- temporäre Datei verwenden
- Datei ersetzen (rename)
- Race Conditions vermeiden

Kein direktes Überschreiben.

------------------------------------------------------------
------------------------------------------------------------

# 11. FEHLERBEHANDLUNG

Writer muss:

- ungültige Patches ablehnen
- fehlende Pflichtfelder erkennen
- JSON-Korruption verhindern

Reader muss:

- bei fehlerhaftem JSON sauber reagieren
- niemals schreiben

------------------------------------------------------------
------------------------------------------------------------

# 12. ARCHITEKTUR-GARANTIE

Durch diese Trennung ist garantiert:

- Kein Modul kann den Event-Store beschädigen
- Kein Trigger kann workflow manipulieren
- Kein API-Endpoint kann Race Conditions erzeugen
- Kein direkter Dateizugriff entsteht

------------------------------------------------------------
------------------------------------------------------------
