# 119_structure_data_layout.md
# CRM V2 – DATEI- UND SPEICHERSTRUKTUR

Status: Verbindliche Strukturdefinition  
Zweck: Physische Trennung von Systemdaten und Kundendaten

------------------------------------------------------------
------------------------------------------------------------

# 1. GRUNDPRINZIP

Das CRM unterscheidet strikt zwischen:

1) Systemdaten (CRM-Betrieb)
2) Kundendaten (fachliche Inhalte / Dokumente)

Diese Bereiche dürfen NICHT vermischt werden.

------------------------------------------------------------
------------------------------------------------------------

# 2. PFAD-PLATZHALTER (VERBINDLICH)

In der gesamten Doku werden folgende Platzhalter verwendet:

<ROOT>            = physisches Account-Root  
<crm_config>      = CRM_CFG('paths','crm_config')  
<crm_data>        = CRM_CFG('paths','crm_data')  
<crm_archiv>      = CRM_CFG('paths','crm_archiv')  
<kunden_storage>  = CRM_CFG('paths','kunden')  
<log>             = CRM_CFG('paths','log')  
<tmp>             = CRM_CFG('paths','tmp')  

In Dokumentation werden KEINE echten Ordnernamen wie /data/ verwendet.

------------------------------------------------------------
------------------------------------------------------------

# 3. CRM SYSTEMDATEN

Speicherort: <crm_data>

Enthält ausschließlich:

- events.json
- kunden.json
- contacts.json
- kunden_phone_map.json
- interne Cache-Dateien
- technische JSON-Exports
- Modul-spezifische technische Daten

Beispiele:

<crm_data>/events.json  
<crm_data>/kunden.json  
<crm_data>/contacts.json  
<crm_data>/login/mitarbeiter.json  

Regel:

Systemdaten dienen dem Betrieb des CRM.  
Sie enthalten KEINE fachlichen Kundendokumente.

------------------------------------------------------------
------------------------------------------------------------

# 4. CRM KONFIGURATION

Speicherort: <crm_config>

Enthält:

- settings_*.php
- secrets_*.php
- defs_*.php

Keine Laufzeitdaten.  
Keine Kundendaten.  
Keine Events.

------------------------------------------------------------
------------------------------------------------------------

# 5. CRM ARCHIV

Speicherort: <crm_archiv>

Enthält:

- rotierte Logs
- Event-Backups
- alte Snapshots
- technische Archivdaten

NICHT:

- aktive Kundendokumente
- Event-Anhänge

------------------------------------------------------------
------------------------------------------------------------

# 6. KUNDENDATEN (FACHLICHER SPEICHER)

Speicherort: <kunden_storage>

Struktur:

<kunden_storage>/<KN>/<modul>/<jahr>/<typ>/

Beispiel:

<kunden_storage>/10032/camera/2026/images/  
<kunden_storage>/10032/service/2026/pdf/  
<kunden_storage>/10032/praxisanalyse/2026/json/  

Definition:

KN = Kundennummer (Primärschlüssel)

------------------------------------------------------------
------------------------------------------------------------

# 7. REGEL: MODUL → JAHR → TYP

Kundendaten folgen immer diesem Muster:

<KN>/<modul>/<jahr>/<typ>/

Begründung:

- klare Archivierung
- einfache Backup-Strategie
- saubere Trennung von Event-Daten
- langfristige Wartbarkeit

------------------------------------------------------------
------------------------------------------------------------

# 8. WICHTIGE VERBOTE

VERBOTEN:

- Kundendokumente unter <crm_data> speichern
- Events unter <kunden_storage> speichern
- Dateipfade im Event speichern
- absolute Serverpfade im JSON speichern
- gemischte Datenstrukturen

------------------------------------------------------------
------------------------------------------------------------

# 9. EVENTS UND DATEIEN

Events enthalten:

- Metadaten
- refs
- timing
- workflow
- meta

Events enthalten NICHT:

- physische Speicherpfade
- Dateisystem-Details

Falls ein Event auf ein Dokument verweist:

→ Referenz über meta  
→ Zugriff über Modul-Logik  
→ Keine direkte Pfadangabe im Event

------------------------------------------------------------
------------------------------------------------------------

# 10. ZUKÜNFTIGE MODULE

Neue Module (z. B. praxisanalyse, dokumentation, logbuch)
müssen:

1) Technische Daten in <crm_data> speichern (falls nötig)
2) Fachliche Dokumente in <kunden_storage> speichern
3) Niemals gemischte Speicherorte verwenden

------------------------------------------------------------
------------------------------------------------------------

# 11. ZUSAMMENFASSUNG

Systemdaten leben unter:
<crm_data>

Kundendaten leben unter:
<kunden_storage>

Diese Trennung ist verbindlich.

------------------------------------------------------------
------------------------------------------------------------
