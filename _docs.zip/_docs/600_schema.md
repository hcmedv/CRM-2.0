# 600_schema.md
# CRM V2 – EVENT SCHEMA (VERBINDLICH)

Version: v2
Status: Normative Referenz

------------------------------------------------------------
------------------------------------------------------------

# 1. ZIEL

Dieses Dokument definiert verbindlich:

- Event Root-Struktur
- Pflichtfelder
- Workflow-Regeln
- Trigger-Entkopplung
- Workload-Prinzip
- Merge-Grundsätze
- Benennungsregeln

Dieses Dokument enthält KEINE historischen Diskussionen.
Historische Entwicklung siehe:
901_schema_history.md

------------------------------------------------------------
------------------------------------------------------------

# 2. ARCHITEKTUR-GRUNDSATZ

DAS EVENT IST DER FACHLICHE CONTAINER.

TRIGGER (pbx, teamviewer, m365, user, api, etc.) liefern nur Daten.

Trigger steuern NICHT:

- workflow.state
- Prioritäten
- Archivierung
- fachliche Entscheidungen

Triggerdaten leben ausschließlich in:

meta.<source>.*

------------------------------------------------------------
------------------------------------------------------------

# 3. VERBINDLICHE ROOT-STRUKTUR

JEDES Event MUSS enthalten:

- event_id
- event_type
- event_source
- created_at
- updated_at
- workflow
- timing

------------------------------------------------------------
------------------------------------------------------------

# 4. WORKFLOW (PFLICHT)

workflow:
  state: open

Regeln:

- workflow.state ist verpflichtend
- Begriff ist ausschließlich "state"
- "status" ist ungültig
- state wird durch Benutzer bestimmt
- state wird NICHT durch Trigger gesetzt

Details siehe:
200_workflow_states.md
210_workflow_transitions.md

------------------------------------------------------------
------------------------------------------------------------

# 5. TIMING (PFLICHT)

timing:
  started_at
  ended_at
  duration_sec

Oder minimal:

timing: {}

Regeln:

- timing Block muss existieren
- duration_sec nur wenn started_at + ended_at vorhanden
- timing steuert nicht workflow.state

------------------------------------------------------------
------------------------------------------------------------

# 6. DISPLAY

Nur Anzeige.
Keine Logik.
Keine Statusentscheidungen.

------------------------------------------------------------
------------------------------------------------------------

# 7. REFS

Idempotenz-Anker.

Merge erfolgt ausschließlich über:

refs[].ns + refs[].id

------------------------------------------------------------
------------------------------------------------------------

# 8. WORKLOG

Optional.
Workload basiert auf:

- timing
- optional worklog
- CRM-Rundungslogik

------------------------------------------------------------
------------------------------------------------------------

# 9. EVENTS STORE ZUGRIFF

events.json darf ausschließlich verwendet werden über:

- _lib/events/crm_events_read.php
- _lib/events/crm_events_write.php

api_* Endpoints greifen niemals direkt auf events.json zu.

Details siehe:
400_runtime.md
410_writer_contract.md
500_flow.md

------------------------------------------------------------
------------------------------------------------------------

# 10. BENENNUNGSREGELN

- snake_case für alle JSON Keys
- keine camelCase Keys
- kein workflow.status
- keine Dateipfade im Event

------------------------------------------------------------
------------------------------------------------------------

# 11. VERBOTENE MUSTER

- workflow aus Triggerdaten ableiten
- Session-Ende = closed
- Hangup = abgeschlossen
- Hardcodierte Pfade
- Direktzugriff auf events.json

------------------------------------------------------------
------------------------------------------------------------

# 12. STORAGE-HINWEIS

Events speichern keine Dateisystempfade.

Kundendaten liegen ausschließlich unter:

_kunden/<KN>/<modul>/<jahr>/<typ>/

Details siehe:
119_structure_data_layout.md

------------------------------------------------------------
------------------------------------------------------------
